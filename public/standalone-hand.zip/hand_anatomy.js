// Standalone Volumetric 3D Cyan Hand System
// Based on 21-landmark MediaPipe / WebXR topology with volumetric flesh capsules,
// glowing skeletal bones, 21 luminous joints, holographic shader, and pinch VFX.

import * as THREE from 'three';

export const HAND_CONNECTIONS = [
  // Thumb
  [0, 1], [1, 2], [2, 3], [3, 4],
  // Index
  [0, 5], [5, 6], [6, 7], [7, 8],
  // Middle
  [0, 9], [9, 10], [10, 11], [11, 12],
  // Ring
  [0, 13], [13, 14], [14, 15], [15, 16],
  // Pinky
  [0, 17], [17, 18], [18, 19], [19, 20],
  // Palm bridges
  [5, 9], [9, 13], [13, 17]
];

export const FINGER_CHAINS = [
  [1, 2, 3, 4],       // Thumb
  [5, 6, 7, 8],       // Index
  [9, 10, 11, 12],    // Middle
  [13, 14, 15, 16],   // Ring
  [17, 18, 19, 20]    // Pinky
];

// Reference rest poses for standard 21 landmarks (normalized metric hand coordinates, centered at wrist 0)
export const REST_LANDMARKS_OPEN = [
  new THREE.Vector3(0, 0, 0),             // 0: Wrist
  // Thumb
  new THREE.Vector3(-0.032, 0.022, 0.012), // 1: CMC
  new THREE.Vector3(-0.054, 0.048, 0.016), // 2: MCP
  new THREE.Vector3(-0.068, 0.076, 0.014), // 3: IP
  new THREE.Vector3(-0.076, 0.100, 0.010), // 4: Tip
  // Index
  new THREE.Vector3(-0.030, 0.072, 0.002), // 5: MCP
  new THREE.Vector3(-0.034, 0.114, 0.000), // 6: PIP
  new THREE.Vector3(-0.036, 0.142, -0.002),// 7: DIP
  new THREE.Vector3(-0.037, 0.166, -0.004),// 8: Tip
  // Middle
  new THREE.Vector3(-0.005, 0.076, 0.000), // 9: MCP
  new THREE.Vector3(-0.006, 0.124, -0.002),// 10: PIP
  new THREE.Vector3(-0.006, 0.158, -0.005),// 11: DIP
  new THREE.Vector3(-0.006, 0.184, -0.007),// 12: Tip
  // Ring
  new THREE.Vector3(0.020, 0.071, -0.002), // 13: MCP
  new THREE.Vector3(0.024, 0.116, -0.004), // 14: PIP
  new THREE.Vector3(0.026, 0.148, -0.006), // 15: DIP
  new THREE.Vector3(0.027, 0.172, -0.008), // 16: Tip
  // Pinky
  new THREE.Vector3(0.042, 0.062, -0.004), // 17: MCP
  new THREE.Vector3(0.050, 0.098, -0.006), // 18: PIP
  new THREE.Vector3(0.054, 0.124, -0.008), // 19: DIP
  new THREE.Vector3(0.057, 0.146, -0.010)  // 20: Tip
];
